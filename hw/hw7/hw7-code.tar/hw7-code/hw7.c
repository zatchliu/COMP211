/* COMP 211, Fall 2022, Wesleyan University
 * Homework #7
 *
 * More arrays
 */

#include <assert.h>
#include <stdbool.h>
#include <stdio.h>

#include "hw7.h"

buffer empty()
{
    buffer b = {};
    return b;
}

void insert(buffer* b, char c)
{
}

void delete_left(buffer* b)
{
}

void delete_right(buffer* b)
{
}

void move_left(buffer* b)
{
}

void move_right(buffer* b)
{
}

void set(buffer* b, int n)
{
}

void contents(buffer* b, char left[], char right[])
{
    left[0] = '\0';
    right[0] = '\0';
}

void print_buffer(buffer* b)
{
}
