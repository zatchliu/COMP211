/* COMP 211, Fall 2022
 * Lab 12
 *
 * Sets and hash tables
 */

/*  hash(k) returns a hash code for k, satisfiying
 *
 *    0 <= hash(k) < NUM_BUCKET
 *
 *  where NUM_BUCKET is defined in hw8.h.
 */
unsigned int hash(unsigned int);
