/* COMP 211, Fall 2022, Wesleyan University
 * Homework #6
 *
 * Palindromes and sorting.
 */

#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

#include "hw6.h"

/* palindrome_check(A, n) =
 *   true, where A[i] == A[n-1-i] for all i < (n-1-i)
 *   false otherwise
 *
 * Pre-conditions:
 */
bool is_palindrome(char A[])
{
   return true;
}

/*  Insertion sort
 *
 */
void insertion_sort(int A[], int n)
{
}

/*  merge3: performs a 3-way merge
 *
 *  A is divided into 3 sub-arrays which are merged in sorted order
 *     -> lo:m1, m1:m2, m2:hi
 */
void merge3(int A[], int lo, int m1, int m2, int hi)
{
}

/*
 * Implements a recursive 3-way mergesort
 *   -> Divide array into thirds.
 *   -> Recursively sort each third.
 *   -> Merge thirds.
 */
void merge_sort3(int A[], int lo, int hi)
{
}

