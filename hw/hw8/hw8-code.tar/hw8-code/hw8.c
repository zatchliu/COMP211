/* COMP 211, Fall 2022
 * Homework 8
 *
 * Queues
 */

#include <assert.h>
#include <stdlib.h>

#include "comp211.h"
#include "hw8.h"

/*  Replace each function body with your definitions.
 */

bool is_linear(qnode *hd) {
    return true;
}

queue create() {
    queue q;
    return q;
}

bool is_empty(queue *q) {
    return false;
}

void enqueue(queue *q, char c) {
}

char dequeue(queue *q) {
    return -1;
}

int size(queue* q) {
    return -1;
}

void as_array(queue* q, char A[]) {
}

void print(queue *q) {
}
