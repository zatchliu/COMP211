/*
 * Fall 2022, COMP 211: Lab 8
 * Structs, pointers and queues
 *
 * This file implements functions required for queue operations
 */
#include "queue.h"

//-----------------------------------------------------------------
// Functions for simple queue implementation using array
//-----------------------------------------------------------------
void queue_new(queue *Qptr)
{
    Qptr->front = 0;
    Qptr->back = 0;
}

bool queue_empty(queue *Qptr)
{
    return false;
}

void enqueue(queue *Qptr, char c)
{
}

char dequeue(queue *Qptr)
{
     return -1;
}

void queue_print(queue *Qptr)
{
}

//-----------------------------------------------------------------
// Functions for queue implementation using circular array
//-----------------------------------------------------------------
void queue_new_circ(queue *Qptr)
{
    Qptr->front = 0;
    Qptr->back = 0;
}

bool queue_empty_circ(queue *Qptr)
{
       return true;
}

bool queue_full_circ(queue *Qptr)
{
       return false;
}

void enqueue_circ(queue *Qptr, char c)
{
}

char dequeue_circ(queue *Qptr)
{
   return -1;
}

int get_qlen_circ(queue *Qptr)
{
    return 0;
}

void queue_print_circ(queue *Qptr)
{
}

