/*
 * Fall 2022, COMP 211: Lab 9
 *
 * Linked lists
 */

#include <stdio.h>
#include <stdlib.h>

#include "list.h"

list create()
{
    list l;
    l.head = NULL;
    return l;
}

bool is_empty(list *l)
{
    return false;
}

void insert(list *l, int loc, char c)
{

}

char deletion(list *l, int loc)
{
   return -1;
}

char getval(list *l, int loc)
{
   return -1;
}

int size(list *l)
{
   return -1;
}

void print(list *l)
{
    // List is empty, cannot print
    if (is_empty(l)) return;

    // List is not empty, print
    node *node = l->head;
    while (node != NULL) {
        printf("%c ", node->data);
        node = node->next;
    }
    printf("\n");
}
